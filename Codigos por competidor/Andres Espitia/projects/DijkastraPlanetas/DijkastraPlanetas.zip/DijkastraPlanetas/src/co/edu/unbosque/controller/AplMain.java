package co.edu.unbosque.controller;
/**
 * Main
 * @author Esteban Mejia
 * @author Andres Espitia
 *
 */
public class AplMain {
	/**
	 * Metodo main
	 * @param args args
	 */
	public static void main(String[] args) {
		Controller c= new Controller();
	}
}
